package com.redx.gamelab;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(10,10,13), PANEL = Color.rgb(23,23,29), RED = Color.rgb(255,51,75), WHITE = Color.WHITE, MUTED = Color.rgb(164,164,177);
    private LinearLayout root, content, gamesList;
    private EditText search;
    private SharedPreferences prefs;
    private List<ResolveInfo> launchable = new ArrayList<>();
    private Set<String> selected = new HashSet<>();
    private String filter = "";
    private TextView countText;
    private boolean gamingSession = false;
    private TextView sessionStatus;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("redx-games", MODE_PRIVATE);
        selected = new HashSet<>(prefs.getStringSet("games", new HashSet<String>()));
        loadLaunchableApps();
        buildUI();
    }

    private void loadLaunchableApps() {
        Intent intent = new Intent(Intent.ACTION_MAIN, null); intent.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> all = pm.queryIntentActivities(intent, 0);
        launchable.clear();
        for (ResolveInfo r : all) {
            if (r.activityInfo == null || getPackageName().equals(r.activityInfo.packageName)) continue;
            boolean isGame = false;
            try {
                ApplicationInfo ai = getPackageManager().getApplicationInfo(r.activityInfo.packageName, 0);
                if (Build.VERSION.SDK_INT >= 26) isGame = ai.category == ApplicationInfo.CATEGORY_GAME;
            } catch (Exception ignored) {}
            if (isGame) launchable.add(r);
        }
        Collections.sort(launchable, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) { return a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()); }
        });
    }

    private void buildUI() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(18),dp(14),dp(18),dp(28));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        TextView brand = text("REDX  /  GAME LAB", 13, RED, true); brand.setLetterSpacing(.12f); content.addView(brand);
        TextView title = text("GAME\nCONTROL", 34, WHITE, true); title.setTypeface(Typeface.create("sans-serif-black",Typeface.NORMAL)); title.setLineSpacing(0,.95f); margin(title,0,dp(8),0,dp(8)); content.addView(title);
        TextView sub = text("YOUR GAMES. ONE LAUNCHPAD.", 11, MUTED, true); sub.setLetterSpacing(.08f); content.addView(sub);

        LinearLayout hero = card(); hero.setOrientation(LinearLayout.VERTICAL); margin(hero,0,dp(22),0,dp(14));
        TextView h = text("GAMING STATUS",11,RED,true); h.setLetterSpacing(.1f); hero.addView(h);
        TextView status = text("READY TO PLAY",22,WHITE,true); margin(status,0,dp(8),0,dp(12)); hero.addView(status);
        LinearLayout stats = new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(stat("SAVED GAMES", String.valueOf(selected.size())), new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(stat("ANDROID", Build.VERSION.RELEASE), new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(stat("DEVICE", Build.MANUFACTURER), new LinearLayout.LayoutParams(0,-2,1)); hero.addView(stats);
        content.addView(hero);

        LinearLayout turbo = card(); turbo.setOrientation(LinearLayout.VERTICAL); margin(turbo,0,0,0,dp(20));
        TextView turboTitle = text("GAME TURBO PANEL",12,RED,true); turboTitle.setLetterSpacing(.1f); turbo.addView(turboTitle);
        TextView turboDesc = text("Safe session tools • no root required",11,MUTED,false); margin(turboDesc,0,dp(5),0,dp(12)); turbo.addView(turboDesc);
        sessionStatus = text("SESSION OFF  /  NORMAL MODE",10,MUTED,true); margin(sessionStatus,0,0,0,dp(10)); turbo.addView(sessionStatus);
        Button boost = button("⚡  START GAMING SESSION",true); boost.setOnClickListener(v->toggleGamingSession()); turbo.addView(boost);
        LinearLayout row1 = new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL); margin(row1,0,dp(8),0,0);
        Button dnd = button("DO NOT DISTURB",false); dnd.setTextSize(9); dnd.setOnClickListener(v->openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS,"Do Not Disturb settings")); row1.addView(dnd,new LinearLayout.LayoutParams(0,dp(44),1));
        Button battery = button("BATTERY MODE",false); battery.setTextSize(9); margin(battery,dp(8),0,0,0); battery.setOnClickListener(v->openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS,"Battery settings")); row1.addView(battery,new LinearLayout.LayoutParams(0,dp(44),1)); turbo.addView(row1);
        LinearLayout row2 = new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL); margin(row2,0,dp(8),0,0);
        Button wifi = button("NETWORK SETTINGS",false); wifi.setTextSize(9); wifi.setOnClickListener(v->openSettings(Settings.ACTION_WIFI_SETTINGS,"Wi-Fi settings")); row2.addView(wifi,new LinearLayout.LayoutParams(0,dp(44),1));
        Button display = button("DISPLAY SETTINGS",false); display.setTextSize(9); margin(display,dp(8),0,0,0); display.setOnClickListener(v->openSettings(Settings.ACTION_DISPLAY_SETTINGS,"Display settings")); row2.addView(display,new LinearLayout.LayoutParams(0,dp(44),1)); turbo.addView(row2);
        Button statusBtn = button("CHECK NETWORK + BATTERY",false); margin(statusBtn,0,dp(8),0,0); statusBtn.setOnClickListener(v->showDeviceStatus()); turbo.addView(statusBtn);
        content.addView(turbo);

        LinearLayout heading = new LinearLayout(this); heading.setGravity(Gravity.CENTER_VERTICAL); heading.setOrientation(LinearLayout.HORIZONTAL);
        TextView gt = text("MY GAME LIBRARY",16,WHITE,true); heading.addView(gt,new LinearLayout.LayoutParams(0,-2,1));
        Button add = button("+ ADD GAME", true); add.setOnClickListener(v -> showPicker()); heading.addView(add); margin(heading,0,dp(10),0,dp(10)); content.addView(heading);
        search = new EditText(this); search.setSingleLine(true); search.setTextColor(WHITE); search.setHintTextColor(MUTED); search.setHint("Search games..."); search.setTextSize(14); search.setPadding(dp(14),0,dp(14),0); search.setBackground(shape(PANEL,dp(13),0,Color.TRANSPARENT)); content.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));
        search.addTextChangedListener(new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){filter=s.toString().toLowerCase(); renderGames();} public void afterTextChanged(android.text.Editable e){} });
        countText = text("0 GAMES",10,MUTED,true); margin(countText,dp(2),dp(14),0,dp(8)); content.addView(countText);
        gamesList = new LinearLayout(this); gamesList.setOrientation(LinearLayout.VERTICAL); content.addView(gamesList);

        LinearLayout note = card(); note.setOrientation(LinearLayout.VERTICAL); margin(note,0,dp(18),0,0);
        note.addView(text("GAME TOOLS",12,RED,true)); margin(note.getChildAt(0),0,0,0,dp(8));
        note.addView(text("• Game-category apps only (Android app metadata)\n• One-tap game launch\n• Read-only RAM snapshot\n• Safe session tools and system settings shortcuts",13,MUTED,false));
        Button memory = button("VIEW MEMORY SNAPSHOT",false); margin(memory,0,dp(14),0,0); memory.setOnClickListener(v->showMemory()); note.addView(memory);
        Button refresh = button("REFRESH APP LIST",false); margin(refresh,0,dp(8),0,0); refresh.setOnClickListener(v->{loadLaunchableApps();renderGames();toast("App list refreshed");}); note.addView(refresh); content.addView(note);
        setContentView(root); renderGames();
    }

    private LinearLayout stat(String label,String value) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(8),dp(10),dp(4),dp(4));
        box.addView(text(label,9,MUTED,true)); TextView val=text(value==null?"?":value.toUpperCase(),15,WHITE,true); margin(val,0,dp(5),0,0); box.addView(val); return box;
    }
    private void renderGames() {
        if (gamesList == null) return;
        gamesList.removeAllViews(); List<ResolveInfo> chosen = new ArrayList<>();
        for (ResolveInfo r : launchable) if (selected.contains(r.activityInfo.packageName) && r.loadLabel(getPackageManager()).toString().toLowerCase().contains(filter)) chosen.add(r);
        countText.setText(chosen.size()+" SAVED GAME"+(chosen.size()==1?"":"S")+"  •  "+launchable.size()+" LAUNCHABLE APPS FOUND");
        if (chosen.isEmpty()) {
            LinearLayout empty=card(); empty.setOrientation(LinearLayout.VERTICAL); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(20),dp(26),dp(20),dp(26));
            TextView icon=text("＋",30,RED,true); empty.addView(icon); TextView msg=text(selected.isEmpty()?"ADD YOUR FIRST GAME":"NO MATCHING GAMES",16,WHITE,true); margin(msg,0,dp(6),0,dp(5)); empty.addView(msg);
            empty.addView(text("Choose a game installed on your phone.",12,MUTED,false)); Button add=button("CHOOSE INSTALLED GAME",true); margin(add,0,dp(15),0,0); add.setOnClickListener(v->showPicker()); empty.addView(add); gamesList.addView(empty); return;
        }
        for (ResolveInfo r:chosen) gamesList.addView(gameRow(r));
    }
    private View gameRow(ResolveInfo r) {
        String pkg=r.activityInfo.packageName, label=r.loadLabel(getPackageManager()).toString();
        LinearLayout row=card(); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); margin(row,0,0,0,dp(10));
        ImageView icon=new ImageView(this); try{icon.setImageDrawable(r.loadIcon(getPackageManager()));}catch(Exception ignored){} row.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout details=new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.setPadding(dp(12),0,dp(5),0); details.addView(text(label,15,WHITE,true)); TextView packageText=text(pkg,9,MUTED,false); packageText.setMaxLines(1); packageText.setEllipsize(android.text.TextUtils.TruncateAt.END); margin(packageText,0,dp(4),0,0); details.addView(packageText); row.addView(details,new LinearLayout.LayoutParams(0,-2,1));
        Button play=button("PLAY",true); play.setMinWidth(dp(64)); play.setOnClickListener(v->launchGame(pkg)); row.addView(play);
        Button remove=button("×",false); remove.setMinWidth(dp(42)); margin(remove,dp(6),0,0,0); remove.setOnClickListener(v->{selected.remove(pkg);saveGames();renderGames();}); row.addView(remove);
        row.setOnClickListener(v->launchGame(pkg)); return row;
    }
    private void showPicker() {
        final List<ResolveInfo> candidates=new ArrayList<>(); for(ResolveInfo r:launchable) if(!selected.contains(r.activityInfo.packageName)) candidates.add(r);
        if(candidates.isEmpty()){toast("All visible apps are already added");return;}
        String[] names=new String[candidates.size()]; boolean[] checked=new boolean[candidates.size()];
        for(int i=0;i<candidates.size();i++){names[i]=candidates.get(i).loadLabel(getPackageManager()).toString();checked[i]=false;}
        new AlertDialog.Builder(this).setTitle("ADD DETECTED GAMES").setMultiChoiceItems(names,checked,(d,which,isChecked)->checked[which]=isChecked)
            .setNegativeButton("CANCEL",null).setPositiveButton("ADD SELECTED",(d,w)->{for(int i=0;i<candidates.size();i++)if(checked[i])selected.add(candidates.get(i).activityInfo.packageName);saveGames();renderGames();toast("Game library updated");}).show();
    }
    private void launchGame(String pkg) {
        try { Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i==null){toast("This app has no launch screen");return;} i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch(Exception e){toast("Could not open app: "+e.getMessage());}
    }
    private void toggleGamingSession() {
        gamingSession = !gamingSession;
        if (gamingSession) {
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            applyImmersiveMode();
            sessionStatus.setText("SESSION ACTIVE  /  SCREEN AWAKE + IMMERSIVE");
            sessionStatus.setTextColor(RED);
            toast("Gaming session enabled. No CPU/GPU overclock applied.");
        } else {
            getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            getWindow().getDecorView().setSystemUiVisibility(0);
            sessionStatus.setText("SESSION OFF  /  NORMAL MODE");
            sessionStatus.setTextColor(MUTED);
            toast("Gaming session ended");
        }
        // Rebuild button label by updating the first button in the turbo card.
        if (content != null && content.getChildCount() > 4) {
            View candidate = content.getChildAt(4);
            if (candidate instanceof LinearLayout) {
                LinearLayout panel = (LinearLayout) candidate;
                for (int i=0;i<panel.getChildCount();i++) {
                    View child=panel.getChildAt(i);
                    if(child instanceof Button && ((Button)child).getText().toString().contains("GAMING SESSION")) {
                        ((Button)child).setText(gamingSession ? "■  STOP GAMING SESSION" : "⚡  START GAMING SESSION"); break;
                    }
                }
            }
        }
    }
    private void applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && gamingSession) applyImmersiveMode();
    }
    @Override protected void onDestroy() {
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }
    private void openSettings(String action, String label) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch(Exception ignored) { toast("Cannot open settings"); } }
    }
    private void showDeviceStatus() {
        String network = "Unknown";
        try {
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni=cm==null?null:cm.getActiveNetworkInfo();
            if(ni==null || !ni.isConnected()) network="Offline";
            else if(ni.getType()==ConnectivityManager.TYPE_WIFI) network="Connected via Wi-Fi";
            else if(ni.getType()==ConnectivityManager.TYPE_MOBILE) network="Connected via mobile data";
            else network="Connected ("+ni.getTypeName()+")";
        } catch(Exception ignored) {}
        String battery="Battery status unavailable";
        try {
            Intent b=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if(b!=null){int level=b.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);int scale=b.getIntExtra(BatteryManager.EXTRA_SCALE,100);int pct=scale>0&&level>=0?Math.round(level*100f/scale):-1;int status=b.getIntExtra(BatteryManager.EXTRA_STATUS,-1);boolean charging=status==BatteryManager.BATTERY_STATUS_CHARGING||status==BatteryManager.BATTERY_STATUS_FULL;battery="Battery: "+(pct>=0?pct+"%":"unknown")+" • "+(charging?"charging":"not charging");}
        } catch(Exception ignored) {}
        new AlertDialog.Builder(this).setTitle("LIVE DEVICE STATUS").setMessage("Network: "+network+"\n"+battery+"\n\nThese are Android-reported snapshots. Network quality and game ping are not guaranteed.").setPositiveButton("OK",null).show();
    }
    private void saveGames(){prefs.edit().putStringSet("games",new HashSet<>(selected)).apply();}
    private void showMemory() {
        ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE); ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi);
        String msg="Available RAM: "+(mi.availMem/1024/1024)+" MB\nTotal RAM: "+(mi.totalMem/1024/1024)+" MB\nLow-memory state: "+(mi.lowMemory?"Yes":"No")+"\n\nThis is a read-only system snapshot. REDX does not clear RAM or force-stop other apps.";
        new AlertDialog.Builder(this).setTitle("DEVICE MEMORY").setMessage(msg).setPositiveButton("OK",null).show();
    }
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setPadding(dp(14),dp(14),dp(14),dp(14));l.setBackground(shape(PANEL,dp(18),dp(1),Color.rgb(48,35,42)));return l;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));return t;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT_BOLD);b.setTextColor(WHITE);b.setPadding(dp(10),0,dp(10),0);b.setMinHeight(dp(40));b.setBackground(shape(primary?RED:Color.rgb(35,35,43),dp(12),dp(1),primary?RED:Color.rgb(68,68,78)));return b;}
    private GradientDrawable shape(int color,int radius,int stroke,int strokeColor){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(stroke>0)d.setStroke(stroke,strokeColor);return d;}
    private void margin(View v,int l,int t,int r,int b){ViewGroup.LayoutParams p=v.getLayoutParams();if(p instanceof ViewGroup.MarginLayoutParams){((ViewGroup.MarginLayoutParams)p).setMargins(l,t,r,b);v.setLayoutParams(p);}}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
