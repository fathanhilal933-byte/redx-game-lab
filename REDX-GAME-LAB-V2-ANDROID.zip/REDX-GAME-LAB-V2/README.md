# REDX GAME LAB V2 — Android Native

Mobile-first Android app launcher with a premium black/red theme. The app lets users choose launchable apps installed on the phone, save selected apps as their game library, search that library, launch apps, remove shortcuts, and view a read-only Android memory snapshot.

## Build APK

### Android Studio
1. Extract this project ZIP.
2. Open the `REDX-GAME-LAB-V2` folder in Android Studio.
3. Allow Gradle sync (Android Gradle Plugin 8.6.1; Gradle 8.7+; JDK 17; Android SDK 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions (phone-friendly route)
1. Upload the extracted project to a GitHub repository.
2. Open the **Actions** tab and run **Build REDX GAME LAB APK**.
3. Download the `REDX-GAME-LAB-debug-apk` artifact after the workflow finishes.

## What really works
- Lists apps that Android exposes through launcher intents.
- User selects which apps to keep in the game library (Android cannot reliably label every app as a game).
- Launches selected apps using Android's package launch intent.
- Search, remove shortcuts, and persist the game library locally.
- Reads Android version/build manufacturer and a read-only system memory snapshot.
- Works offline after installation.

## Important limits
- This is a game launcher, not Xiaomi's privileged Game Turbo service.
- It does not overclock CPU/GPU, clear other apps' RAM, force-stop background processes, change thermal policy, or measure FPS inside other games.
- The app list is limited to apps Android exposes as launchable. Apps hidden by the system or with no launcher activity may not appear.
- The APK is a project source package; it must be built with Android Studio or GitHub Actions before installation. No prebuilt APK is claimed here.


## V2 Turbo Panel
- Game-only library uses Android app category metadata (`CATEGORY_GAME`). Some games may not appear if their developers did not mark them as games; this is an Android metadata limitation.
- Gaming Session keeps the REDX screen awake and hides system bars while REDX itself is open. It does not change CPU/GPU clocks or boost other apps.
- Do Not Disturb, Battery, Wi-Fi, and Display buttons open Android settings pages; the user makes any system changes there.
- Network + Battery panel reads the Android-reported active network type and battery percentage/charging state. It does not measure game-server ping.
- Memory snapshot is read-only. Android does not allow ordinary apps to force-stop other apps or truly clear system RAM.
- No root, no account, and no internet required for core features.
